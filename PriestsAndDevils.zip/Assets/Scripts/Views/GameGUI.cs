﻿using System.Collections;
using System.Collections.Generic;

using UnityEngine;

namespace PriestsAndDevils
{
  public class GameGUI : MonoBehaviour
  {
    public Result result;
    private IUserAction action;

    private const string title = "牧师与魔鬼";
    private const string rule =
      @"蓝色: 牧师   红色: 魔鬼
三个牧师和三个魔鬼想过河。
这艘船每次只能载两个人。
必须有一个人来掌舵。
单击人或船使其移动。
当双方都少于恶魔时，牧师就会被杀。
你应该让所有的牧师活着！";

    private const string exit = "退出";
    private const string restart = "重置游戏";

    // Use this for initialization
    void Start()
    {
      result = Result.GAMING; // 初始化为未完成状态
      action = Director.GetInstance().currentSceneController as IUserAction;
    }

    void OnGUI()
    {

      // 标题的样式
      var textStyle = new GUIStyle()
      {
        fontSize = 40,
        alignment = TextAnchor.MiddleCenter
      };
      GUI.Label(new Rect(Screen.width / 2 - 50, Screen.height / 2 - 280, 100, 50), title, textStyle); // 游戏标题

      // 规则的样式
      var ruleStyle = new GUIStyle
      {
        fontSize = 20,
        fontStyle = FontStyle.Normal,
        alignment = TextAnchor.MiddleCenter
      };
      GUI.Label(new Rect(Screen.width / 2 - 50, Screen.height / 2 - 110, 100, 50), rule, ruleStyle); // 游戏规则

      // 按钮的样式
      var buttonStyle = new GUIStyle("button")
      {
        fontSize = 15,
      };

      // 游戏结束
      if (result != Result.GAMING)
      {
        var text = result == Result.WINNER ? "You Win!" : "You Lose!";
        GUI.Label(new Rect(Screen.width / 2 - 50, Screen.height / 2 + 50, 100, 50), text, textStyle);
      }

      // 重置游戏按钮
      if (GUI.Button(new Rect(Screen.width / 2 - 140, Screen.height / 2 + 140, 100, 40), restart, buttonStyle))
      {
        action.Reset();
      }

      // 退出游戏按钮
      if (GUI.Button(new Rect(Screen.width / 2 + 40, Screen.height / 2 + 140, 100, 40), exit, buttonStyle))
      {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
      }


    }

    // 使用射线捕捉来获取游戏对象
    void Update()
    {
      if (Input.GetButtonDown("Fire1")) // 判断按键
      {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out RaycastHit hit, 100f))
        {
          var todo = hit.collider;
          var character = todo.GetComponent<CharacterController>(); // 获取角色
          if (character)                                            // 如果是角色
          {
            action.ClickCharacter(character);
          }
          else if (todo.transform.name == "Boat") // 如果不是，那么判断是否是船
          {
            action.ClickBoat();
          }
        }
      }
    }
  }
}
